<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Recurring_Event_Cleanup' );


	class TribeRecurringEventCleanup extends Tribe__Events__Recurring_Event_Cleanup {

	}