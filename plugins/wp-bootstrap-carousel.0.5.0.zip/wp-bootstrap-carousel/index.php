<?php
// silentium est aureum
